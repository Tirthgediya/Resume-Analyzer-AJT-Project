package com.resumeanalyzer.model;

public class JobRole {
    private int roleId;
    private String domain;
    private String roleName;
    private String skillKeywords;
    
    public JobRole() {}
    
    public int getRoleId() { return roleId; }
    public void setRoleId(int roleId) { this.roleId = roleId; }
    public String getDomain() { return domain; }
    public void setDomain(String domain) { this.domain = domain; }
    public String getRoleName() { return roleName; }
    public void setRoleName(String roleName) { this.roleName = roleName; }
    public String getSkillKeywords() { return skillKeywords; }
    public void setSkillKeywords(String skillKeywords) { this.skillKeywords = skillKeywords; }
}