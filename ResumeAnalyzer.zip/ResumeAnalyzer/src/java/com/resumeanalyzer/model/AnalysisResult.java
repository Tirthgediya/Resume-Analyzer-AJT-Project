package com.resumeanalyzer.model;

import java.sql.Timestamp;

public class AnalysisResult {
    private int id;
    private int studentId;
    private String predictedDomain;
    private String predictedRole;
    private int score;
    private String missingSkills;
    private Timestamp analysisDate;
    private Student student;
    
    public AnalysisResult() {}
    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }
    public String getPredictedDomain() { return predictedDomain; }
    public void setPredictedDomain(String predictedDomain) { this.predictedDomain = predictedDomain; }
    public String getPredictedRole() { return predictedRole; }
    public void setPredictedRole(String predictedRole) { this.predictedRole = predictedRole; }
    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }
    public String getMissingSkills() { return missingSkills; }
    public void setMissingSkills(String missingSkills) { this.missingSkills = missingSkills; }
    public Timestamp getAnalysisDate() { return analysisDate; }
    public void setAnalysisDate(Timestamp analysisDate) { this.analysisDate = analysisDate; }
    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }
}