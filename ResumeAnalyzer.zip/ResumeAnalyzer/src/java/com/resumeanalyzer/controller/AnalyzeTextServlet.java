package com.resumeanalyzer.controller;

import com.resumeanalyzer.service.ResumeAnalysisService;
import com.resumeanalyzer.service.DataStorageService;
import java.io.IOException;
import java.util.Map;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AnalyzeTextServlet extends HttpServlet {
    
    private ResumeAnalysisService analysisService;
    private DataStorageService dataStorage;
    
    @Override
    public void init() throws ServletException {
        analysisService = new ResumeAnalysisService();
        dataStorage = DataStorageService.getInstance();
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String resumeText = request.getParameter("resumeText");
        
        if (name == null || name.trim().isEmpty()) {
            response.sendRedirect("analyze.jsp?error=Please enter your name");
            return;
        }
        
        if (email == null || email.trim().isEmpty()) {
            response.sendRedirect("analyze.jsp?error=Please enter your email");
            return;
        }
        
        if (resumeText == null || resumeText.trim().isEmpty()) {
            response.sendRedirect("analyze.jsp?error=Please paste your resume text");
            return;
        }
        
        try {
            // Analyze resume text
            Map<String, Object> analysisResult = analysisService.analyzeResume(resumeText);
            
            // Store analysis in memory
            int analysisId = dataStorage.storeAnalysis(name, email, analysisResult);
            
            // Set attributes for JSP
            request.setAttribute("analysisResult", analysisResult);
            request.setAttribute("studentName", name);
            request.setAttribute("studentEmail", email);
            request.setAttribute("missingItems", analysisResult.get("missingItems"));
            request.setAttribute("analysisId", analysisId);
            
            // Forward to result page
            RequestDispatcher dispatcher = request.getRequestDispatcher("analysis_result.jsp");
            dispatcher.forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("analyze.jsp?error=Analysis failed: " + e.getMessage());
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.sendRedirect("analyze.jsp");
    }
}