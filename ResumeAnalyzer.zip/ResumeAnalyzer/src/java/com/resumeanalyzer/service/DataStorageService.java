package com.resumeanalyzer.service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class DataStorageService {
    private static DataStorageService instance;
    private final Map<Integer, Map<String, Object>> analyses;
    private final AtomicInteger analysisIdCounter;
    
    // Private constructor for singleton pattern
    private DataStorageService() {
        this.analyses = new ConcurrentHashMap<>();
        this.analysisIdCounter = new AtomicInteger(1);
    }
    
    // Singleton instance
    public static synchronized DataStorageService getInstance() {
        if (instance == null) {
            instance = new DataStorageService();
        }
        return instance;
    }
    
    // Store analysis result
    public int storeAnalysis(String name, String email, Map<String, Object> analysisResult) {
        int analysisId = analysisIdCounter.getAndIncrement();
        
        Map<String, Object> analysisData = new HashMap<>();
        analysisData.put("id", analysisId);
        analysisData.put("name", name);
        analysisData.put("email", email);
        analysisData.put("domain", analysisResult.get("domain"));
        analysisData.put("role", analysisResult.get("role"));
        analysisData.put("score", analysisResult.get("score"));
        analysisData.put("missingItems", analysisResult.get("missingItems"));
        analysisData.put("timestamp", new Date());
        
        analyses.put(analysisId, analysisData);
        return analysisId;
    }
    
    // Get all analyses
    public List<Map<String, Object>> getAllAnalyses() {
        List<Map<String, Object>> allAnalyses = new ArrayList<>();
        
        for (Map<String, Object> analysis : analyses.values()) {
            allAnalyses.add(new HashMap<>(analysis)); // Return a copy
        }
        
        // Sort by timestamp (newest first)
        allAnalyses.sort((a1, a2) -> {
            Date date1 = (Date) a2.get("timestamp");
            Date date2 = (Date) a1.get("timestamp");
            return date1.compareTo(date2);
        });
        
        return allAnalyses;
    }
    
    // Get analysis count
    public int getAnalysisCount() {
        return analyses.size();
    }
    
    // Get today's analysis count
    public int getTodaysAnalysisCount() {
        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);
        
        int count = 0;
        for (Map<String, Object> analysis : analyses.values()) {
            Date timestamp = (Date) analysis.get("timestamp");
            if (timestamp.after(today.getTime())) {
                count++;
            }
        }
        return count;
    }
    
    // Clear all data (for testing)
    public void clearAllData() {
        analyses.clear();
        analysisIdCounter.set(1);
    }
}