package com.resumeanalyzer.service;

import java.util.*;

public class ResumeAnalysisService {
    
    public Map<String, Object> analyzeResume(String resumeText) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // Use default job roles instead of database
            List<JobRole> jobRoles = getDefaultJobRoles();
            
            String bestRole = "General";
            String bestDomain = "General";
            int bestScore = 0;
            List<String> missingSkills = new ArrayList<>();
            String resumeTextLower = resumeText.toLowerCase();
            
            for (JobRole role : jobRoles) {
                if (role.getSkillKeywords() == null) continue;
                
                String[] skills = role.getSkillKeywords().split(",");
                int matchCount = 0;
                List<String> roleMissingSkills = new ArrayList<>();
                
                for (String skill : skills) {
                    String cleanSkill = skill.trim().toLowerCase();
                    if (!cleanSkill.isEmpty() && resumeTextLower.contains(cleanSkill)) {
                        matchCount++;
                    } else {
                        roleMissingSkills.add(skill.trim());
                    }
                }
                
                int score = skills.length > 0 ? (int) ((double) matchCount / skills.length * 100) : 0;
                
                if (score > bestScore) {
                    bestScore = score;
                    bestRole = role.getRoleName();
                    bestDomain = role.getDomain();
                    missingSkills = roleMissingSkills;
                }
            }
            
            // Get only the missing items
            List<String> missingItems = getMissingItems(resumeText, missingSkills);
            
            result.put("domain", bestDomain);
            result.put("role", bestRole);
            result.put("score", bestScore);
            result.put("missingItems", missingItems);
            
        } catch (Exception e) {
            // If any error, return basic analysis without database
            result = getBasicAnalysis(resumeText);
        }
        
        return result;
    }
    
    private Map<String, Object> getBasicAnalysis(String resumeText) {
        Map<String, Object> result = new HashMap<>();
        String resumeTextLower = resumeText.toLowerCase();
        
        // Simple analysis without database
        if (resumeTextLower.contains("java") && resumeTextLower.contains("spring")) {
            result.put("domain", "IT");
            result.put("role", "Java Developer");
            result.put("score", 75);
        } else if (resumeTextLower.contains("python") && resumeTextLower.contains("sql")) {
            result.put("domain", "IT");
            result.put("role", "Data Analyst");
            result.put("score", 70);
        } else if (resumeTextLower.contains("html") && resumeTextLower.contains("css")) {
            result.put("domain", "IT");
            result.put("role", "Web Developer");
            result.put("score", 65);
        } else {
            result.put("domain", "IT");
            result.put("role", "Software Professional");
            result.put("score", 50);
        }
        
        // Get missing items
        List<String> missingItems = getMissingItems(resumeText, new ArrayList<>());
        result.put("missingItems", missingItems);
        
        return result;
    }
    
    private List<String> getMissingItems(String resumeText, List<String> missingSkills) {
        List<String> missingItems = new ArrayList<>();
        
        // Check for missing sections
        if (!resumeText.toLowerCase().contains("experience") && !resumeText.toLowerCase().contains("work")) {
            missingItems.add("Work Experience section");
        }
        
        if (!resumeText.toLowerCase().contains("education") && !resumeText.toLowerCase().contains("degree")) {
            missingItems.add("Education section");
        }
        
        if (!resumeText.toLowerCase().contains("skill") && !resumeText.toLowerCase().contains("technical")) {
            missingItems.add("Skills section");
        }
        
        if (!resumeText.toLowerCase().contains("project")) {
            missingItems.add("Projects section");
        }
        
        // Check for contact information
        if (!resumeText.matches(".*\\b\\w+@\\w+\\.\\w+\\b.*")) {
            missingItems.add("Email address");
        }
        
        // Check for missing technical skills (only top 3)
        if (!missingSkills.isEmpty()) {
            List<String> topMissingSkills = missingSkills.subList(0, Math.min(3, missingSkills.size()));
            missingItems.add("Technical skills: " + String.join(", ", topMissingSkills));
        }
        
        // Check resume length
        int wordCount = resumeText.split("\\s+").length;
        if (wordCount < 200) {
            missingItems.add("More detailed content (resume too short)");
        }
        
        return missingItems;
    }
    
    private List<JobRole> getDefaultJobRoles() {
        List<JobRole> defaultRoles = new ArrayList<>();
        
        String[][] rolesData = {
            {"IT", "Java Developer", "java,spring,hibernate,mysql,jdbc"},
            {"IT", "Web Developer", "html,css,javascript,react,nodejs"},
            {"IT", "Data Analyst", "python,sql,excel,tableau,statistics"}
        };
        
        for (String[] roleData : rolesData) {
            JobRole role = new JobRole();
            role.setDomain(roleData[0]);
            role.setRoleName(roleData[1]);
            role.setSkillKeywords(roleData[2]);
            defaultRoles.add(role);
        }
        
        return defaultRoles;
    }
    
    // Inner class for JobRole to avoid database dependency
    class JobRole {
        private String domain;
        private String roleName;
        private String skillKeywords;
        
        public String getDomain() { return domain; }
        public void setDomain(String domain) { this.domain = domain; }
        public String getRoleName() { return roleName; }
        public void setRoleName(String roleName) { this.roleName = roleName; }
        public String getSkillKeywords() { return skillKeywords; }
        public void setSkillKeywords(String skillKeywords) { this.skillKeywords = skillKeywords; }
    }
}