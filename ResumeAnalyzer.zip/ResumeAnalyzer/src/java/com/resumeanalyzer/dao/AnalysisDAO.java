package com.resumeanalyzer.dao;

import com.resumeanalyzer.model.AnalysisResult;
import com.resumeanalyzer.model.JobRole;
import com.resumeanalyzer.model.Student;
import com.resumeanalyzer.util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AnalysisDAO {
    
    public void saveAnalysisResult(AnalysisResult result) throws SQLException {
        String sql = "INSERT INTO analysis_results (student_id, predicted_domain, predicted_role, score, missing_skills) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, result.getStudentId());
            stmt.setString(2, result.getPredictedDomain());
            stmt.setString(3, result.getPredictedRole());
            stmt.setInt(4, result.getScore());
            stmt.setString(5, result.getMissingSkills());
            
            stmt.executeUpdate();
        }
    }
    
    public List<AnalysisResult> getAllAnalysisResults() throws SQLException {
        List<AnalysisResult> results = new ArrayList<>();
        String sql = "SELECT ar.*, s.name, s.email FROM analysis_results ar JOIN students s ON ar.student_id = s.id ORDER BY ar.analysis_date DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                AnalysisResult result = new AnalysisResult();
                result.setId(rs.getInt("id"));
                result.setStudentId(rs.getInt("student_id"));
                result.setPredictedDomain(rs.getString("predicted_domain"));
                result.setPredictedRole(rs.getString("predicted_role"));
                result.setScore(rs.getInt("score"));
                result.setMissingSkills(rs.getString("missing_skills"));
                result.setAnalysisDate(rs.getTimestamp("analysis_date"));
                
                Student student = new Student();
                student.setName(rs.getString("name"));
                student.setEmail(rs.getString("email"));
                result.setStudent(student);
                
                results.add(result);
            }
        }
        return results;
    }
    
    public List<JobRole> getAllJobRoles() throws SQLException {
        List<JobRole> jobRoles = new ArrayList<>();
        String sql = "SELECT * FROM job_roles";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                JobRole role = new JobRole();
                role.setRoleId(rs.getInt("role_id"));
                role.setDomain(rs.getString("domain"));
                role.setRoleName(rs.getString("role_name"));
                role.setSkillKeywords(rs.getString("skill_keywords"));
                jobRoles.add(role);
            }
        }
        return jobRoles;
    }
}