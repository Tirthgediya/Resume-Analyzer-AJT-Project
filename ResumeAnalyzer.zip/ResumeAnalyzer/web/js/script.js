// Client-side validation and functionality
document.addEventListener('DOMContentLoaded', function() {
    // Form validation for upload form
    const uploadForm = document.getElementById('uploadForm');
    if (uploadForm) {
        uploadForm.addEventListener('submit', function(e) {
            const fileInput = document.getElementById('resume');
            const nameInput = document.getElementById('name');
            const emailInput = document.getElementById('email');
            let isValid = true;
            let errorMessage = '';

            // Clear previous errors
            hideMessage('error-message');
            hideMessage('success-message');

            // Validate name
            if (!nameInput.value.trim()) {
                isValid = false;
                errorMessage = 'Please enter your name';
            }

            // Validate email
            else if (!validateEmail(emailInput.value)) {
                isValid = false;
                errorMessage = 'Please enter a valid email address';
            }

            // Validate file
            else if (!fileInput.files[0]) {
                isValid = false;
                errorMessage = 'Please select a PDF file';
            }
            else if (fileInput.files[0].type !== 'application/pdf') {
                isValid = false;
                errorMessage = 'Please select a PDF file only';
            }
            else if (fileInput.files[0].size > 5 * 1024 * 1024) { // 5MB limit
                isValid = false;
                errorMessage = 'File size must be less than 5MB';
            }

            if (!isValid) {
                e.preventDefault();
                showMessage('error-message', errorMessage);
                return false;
            }

            // Show loading indicator
            showLoading();
        });
    }

    // Form validation for login form
    const loginForm = document.querySelector('.login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            const usernameInput = document.getElementById('username');
            const passwordInput = document.getElementById('password');
            let isValid = true;
            let errorMessage = '';

            // Clear previous errors
            hideMessage('error-message');

            // Validate username
            if (!usernameInput.value.trim()) {
                isValid = false;
                errorMessage = 'Please enter username';
            }

            // Validate password
            else if (!passwordInput.value.trim()) {
                isValid = false;
                errorMessage = 'Please enter password';
            }

            if (!isValid) {
                e.preventDefault();
                showMessage('error-message', errorMessage);
                return false;
            }
        });
    }

    // Display URL parameters as messages
    const urlParams = new URLSearchParams(window.location.search);
    const error = urlParams.get('error');
    const success = urlParams.get('success');

    if (error) {
        showMessage('error-message', error);
    }
    if (success) {
        showMessage('success-message', success);
    }
});

// Utility functions
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function showMessage(elementId, message) {
    const element = document.getElementById(elementId);
    if (element) {
        element.textContent = message;
        element.style.display = 'block';
    }
}

function hideMessage(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.style.display = 'none';
    }
}

function showLoading() {
    const loading = document.getElementById('loading');
    if (loading) {
        loading.style.display = 'block';
    }
}

function hideLoading() {
    const loading = document.getElementById('loading');
    if (loading) {
        loading.style.display = 'none';
    }
}

// File input styling
document.addEventListener('DOMContentLoaded', function() {
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fileInputs.forEach(input => {
        input.addEventListener('change', function() {
            const fileName = this.files[0] ? this.files[0].name : 'No file chosen';
            const label = this.previousElementSibling;
            if (label && label.tagName === 'LABEL') {
                label.textContent = fileName;
            }
        });
    });
});
